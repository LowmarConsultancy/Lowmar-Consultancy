import React, { useState } from "react";

export default function App() {
  const [submitted, setSubmitted] = useState(false);

  return (
    <main style={{ padding: "2rem", maxWidth: "600px", margin: "auto" }}>
      <h1>Lowmar Associates</h1>
      <p>
        Expert Consultancy in Health & Social Care | Mentoring & Coaching Services
      </p>

      <h2>Contact Us</h2>
      {submitted ? (
        <p style={{ color: "green" }}>Thank you! We'll be in touch soon.</p>
      ) : (
        <form
          action="https://formspree.io/f/maylrgld"
          method="POST"
          onSubmit={() => setSubmitted(true)}
          style={{ display: "flex", flexDirection: "column", gap: "1rem" }}
        >
          <input name="name" placeholder="Your Name" required />
          <input name="email" type="email" placeholder="Your Email" required />
          <textarea name="message" placeholder="Your Message" required />
          <button type="submit">Submit</button>
        </form>
      )}
    </main>
  );
}